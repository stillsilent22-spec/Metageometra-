# HTM SMBH CASCADE V1

This is the first executable cascade around the frozen 399 x 4 = 1596 HTM SMBH target grid. It deliberately separates **prediction geometry** from **observation/audit channels**.

## What it does now

1. Loads all 1596 preregistered states from the supplied v0.1 coordinate proposal (already extracted into `data/targets_v01.csv`).
2. Verifies 399 complete quartets in the frozen order `B-, A+, B+, A-` and keeps the +/-19.4712 tilt assignments.
3. Converts the frozen Galactic targets to ICRS for survey work without changing their Galactic coordinates.
4. Computes a **projected jet tangent** from each node to the next frozen node on the same arm. For Q399 it points to the Rift closure target. This is a measurement helper, not a retune of the HTM path.
5. Cross-matches supplied candidates inside each target's frozen search radius.
6. Applies a **void-shell stencil / matched filter**. Each target receives a score `exp[-0.5*(|theta_center - theta_void|/sigma)^2]`, i.e. the template is strongest on the projected void shell rather than at the void centre.
7. Compares observed jet position angles with the frozen projected HTM tangent and saves both 180-degree axial and 360-degree directed residuals.
8. Fits multi-frequency spectra separately for `core`, `jet`, or any other supplied component: spectral index and optional curvature are stored.
9. Adds the atomic-iteration cumulative landmarks `T_Z = Z(Z+1)/2` as an **independent audit layer**. It does not change target coordinates or candidate status. Labeled checkpoints include H/He/Li, C/N/O/Ne, Fe/Ni, and Ba/1596.
10. Tests whether measured spectral properties change around those already-declared atomic landmarks. Until a physical mapping from atomic iteration to jet/core spectrum is derived, this output is explicitly `EXPLORATORY` and cannot count as geometric confirmation.
11. Aggregates every four states into a quartet result and propagates an optional temporal-stop rule.
12. Saves everything to SQLite plus CSV exports and an audit log.

## Why the void test is now a template rather than a single nearest-void lookup

The existing void test compares HTM nodes with DESI void structure and notes that the relevant model claim concerns void-shell/rand regions. A nearest-centre test throws away that geometry. The new `void_stencil` stage uses the **distance to the void shell itself**. It therefore asks a sharper question: does the frozen HTM path preferentially intersect the shell/rim geometry that the model claims, rather than merely being near a void centre?

`voids.csv` can provide `angular_radius_deg` directly. If only `z` and `r_eff_mpc` are supplied, the module can create an observational proxy angular radius with a conventional flat-LCDM distance calculation; such rows are explicitly marked `proxy_radius=1` so that this auxiliary conversion is not confused with an HTM distance law.

## Atomic iteration and spectra

The code does **not** assume that atomic iteration changes SMBH or jet spectra. It makes the possibility testable without cross-fitting. Spectral data are reduced first, independently, into quantities such as `alpha` and `curvature`. Only afterward are those quantities compared with the frozen cumulative atomic landmarks. This preserves the rule:

`geometry -> frozen targets`  
`atomic/isotope structure -> independent cross-scale audit`

If a concrete HTM spectral law is later derived, it can be added as a new versioned hypothesis module instead of adjusting the present one after seeing the data.

## Input files

Copy the relevant schema from `schemas/` into `incoming/` and replace the example rows.

- `incoming/candidates.csv` — astronomical candidates.
- `incoming/jets.csv` — measured jet PA and uncertainty; may reference either `candidate_id` or `node_id`.
- `incoming/spectra.csv` — long-format flux/frequency measurements, ideally separated as `core`, `jet`, `integrated`, etc.
- `incoming/voids.csv` — void centres plus angular radii or redshift/effective radius.
- `incoming/blindspots.csv` — extinction/coverage/confusion flags.
- `incoming/temporal_stops.csv` — optional chronology stop.

The previous large `query_manifest.csv` is included under `data/legacy_query_manifest.csv` when available. It can remain the acquisition queue while this module becomes the deterministic analysis/storage layer.

## One-click Windows run

Double-click:

`RUN_HTM_CASCADE.bat`

or from a terminal:

```bash
python htm_cascade.py run --config config.json
```

Outputs are written to `results/`:

- `htm_cascade.sqlite`
- `targets.csv`
- `target_candidates.csv`
- `void_scores.csv`
- `jet_checks.csv`
- `spectral_features.csv`
- `atomic_spectral_audit.csv`
- `quartet_status.csv`
- `audit_log.csv`
- `summary.json`
- `run.log`

## Important audit rule

The module is intentionally asymmetric: observational data may **confirm, fail, leave untested, or expose a blindspot**, but they do not move the frozen geometry. Likewise, the atomic/isotope channel is stored alongside the SMBH channel but cannot rescue a failed astronomical target.
