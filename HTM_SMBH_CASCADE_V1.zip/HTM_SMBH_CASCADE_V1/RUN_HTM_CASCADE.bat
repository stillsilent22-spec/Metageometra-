@echo off
cd /d "%~dp0"
python htm_cascade.py run --config config.json
pause
