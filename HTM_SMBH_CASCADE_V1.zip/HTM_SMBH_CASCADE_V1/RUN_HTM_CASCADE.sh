#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 htm_cascade.py run --config config.json
