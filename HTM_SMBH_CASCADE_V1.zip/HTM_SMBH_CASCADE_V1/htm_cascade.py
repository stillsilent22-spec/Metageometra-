#!/usr/bin/env python3
"""HTM SMBH Cascade V1

Deterministic, auditable cascade around the preregistered 1596-target table.
It does NOT retune HTM geometry from candidates, voids, jets, spectra, or atomic data.
Atomic/void/spectral layers are independent audit channels unless explicitly extended.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, sqlite3, sys, time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
import numpy as np
import pandas as pd

ARM_ORDER = ['B-','A+','B+','A-']
EQ_TO_GAL = np.array([
    [-0.0548755604, -0.8734370902, -0.4838350155],
    [ 0.4941094279, -0.4448296300,  0.7469822445],
    [-0.8676661490, -0.1980763734,  0.4559837762],
], dtype=float)
GAL_TO_EQ = EQ_TO_GAL.T


def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()


def sph_to_vec(lon_deg, lat_deg):
    lon=np.deg2rad(np.asarray(lon_deg,dtype=float)); lat=np.deg2rad(np.asarray(lat_deg,dtype=float))
    c=np.cos(lat)
    return np.stack([c*np.cos(lon), c*np.sin(lon), np.sin(lat)], axis=-1)


def vec_to_sph(v):
    v=np.asarray(v,dtype=float); v=v/np.linalg.norm(v,axis=-1,keepdims=True)
    lon=np.rad2deg(np.arctan2(v[...,1],v[...,0]))%360.0
    lat=np.rad2deg(np.arcsin(np.clip(v[...,2],-1,1)))
    return lon,lat


def gal_to_icrs(l_deg,b_deg):
    gv=sph_to_vec(l_deg,b_deg); ev=gv@GAL_TO_EQ.T
    return vec_to_sph(ev)


def icrs_to_gal(ra_deg,dec_deg):
    ev=sph_to_vec(ra_deg,dec_deg); gv=ev@EQ_TO_GAL.T
    return vec_to_sph(gv)


def angular_sep_deg(lon1,lat1,lon2,lat2):
    a=sph_to_vec(lon1,lat1); b=sph_to_vec(lon2,lat2)
    dot=np.sum(a*b,axis=-1)
    return np.rad2deg(np.arccos(np.clip(dot,-1,1)))


def position_angle_deg(ra1,dec1,ra2,dec2):
    # east of north, [0,360)
    r1,r2=np.deg2rad([ra1,ra2]); d1,d2=np.deg2rad([dec1,dec2])
    y=np.sin(r2-r1)*np.cos(d2)
    x=np.cos(d1)*np.sin(d2)-np.sin(d1)*np.cos(d2)*np.cos(r2-r1)
    return float(np.rad2deg(np.arctan2(y,x))%360.0)


def axial_diff_deg(a,b):
    d=abs((a-b)%180.0); return min(d,180.0-d)


def directed_diff_deg(a,b):
    d=abs((a-b)%360.0); return min(d,360.0-d)


def flat_lcdm_DA_mpc(z,H0=70.0,Om=0.3):
    # observational proxy only; not an HTM distance law
    if not np.isfinite(z) or z<=0: return np.nan
    c=299792.458; zz=np.linspace(0,float(z),512)
    Ez=np.sqrt(Om*(1+zz)**3+(1-Om))
    dc=(c/H0)*np.trapz(1.0/Ez,zz)
    return dc/(1+z)


class Cascade:
    def __init__(self, config_path: Path):
        self.config_path=config_path.resolve(); self.root=self.config_path.parent
        self.cfg=json.loads(self.config_path.read_text(encoding='utf-8'))
        self.db_path=(self.root/self.cfg['database']).resolve(); self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self.out=(self.root/self.cfg['exports_dir']).resolve(); self.out.mkdir(parents=True,exist_ok=True)
        self.inc=(self.root/self.cfg['incoming_dir']).resolve(); self.inc.mkdir(parents=True,exist_ok=True)
        self.conn=sqlite3.connect(self.db_path)
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.run_id=time.strftime('%Y%m%dT%H%M%S')
        self.log=[]

    def close(self): self.conn.close()
    def note(self,msg):
        print(msg); self.log.append(msg)

    def read_csv_if(self,name):
        p=self.inc/name
        if p.exists() and p.stat().st_size>0:
            try: return pd.read_csv(p)
            except Exception as e: self.note(f'[WARN] cannot read {name}: {e}')
        return None

    def init_schema(self):
        c=self.conn
        c.executescript('''
        CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY,started_utc TEXT,config_json TEXT,targets_sha256 TEXT);
        CREATE TABLE IF NOT EXISTS targets(node_id TEXT PRIMARY KEY,quartet INTEGER,arm TEXT,pair TEXT,l_deg REAL,b_deg REAL,ra_deg REAL,dec_deg REAL,r_htm_kpc REAL,phase_deg REAL,block INTEGER,six_pos INTEGER,tilt_deg REAL,handedness TEXT,spin_pred TEXT,catalog_class TEXT,search_radius_deg REAL,preregistered_status TEXT,state_index INTEGER,jet_pa_pred_deg REAL,atomic_Z_landmark INTEGER,atomic_label TEXT);
        CREATE TABLE IF NOT EXISTS candidates(candidate_id TEXT PRIMARY KEY,ra_deg REAL,dec_deg REAL,z REAL,object_class TEXT,source_catalog TEXT,designation TEXT,notes TEXT);
        CREATE TABLE IF NOT EXISTS target_candidates(run_id TEXT,node_id TEXT,candidate_id TEXT,separation_deg REAL,within_window INTEGER,PRIMARY KEY(run_id,node_id,candidate_id));
        CREATE TABLE IF NOT EXISTS void_scores(run_id TEXT,node_id TEXT,void_id TEXT,center_sep_deg REAL,angular_radius_deg REAL,shell_residual_deg REAL,stencil_score REAL,proxy_radius INTEGER,PRIMARY KEY(run_id,node_id,void_id));
        CREATE TABLE IF NOT EXISTS jet_checks(run_id TEXT,node_id TEXT,candidate_id TEXT,observed_pa_deg REAL,predicted_pa_deg REAL,axial_residual_deg REAL,directed_residual_deg REAL,pa_unc_deg REAL,source TEXT);
        CREATE TABLE IF NOT EXISTS spectral_features(run_id TEXT,node_id TEXT,candidate_id TEXT,component TEXT,n_points INTEGER,alpha REAL,curvature REAL,lognu_min REAL,lognu_max REAL,source_count INTEGER);
        CREATE TABLE IF NOT EXISTS atomic_spectral_audit(run_id TEXT,Z INTEGER,T_Z INTEGER,node_id TEXT,label TEXT,n_before INTEGER,n_after INTEGER,delta_alpha REAL,delta_curvature REAL,status TEXT);
        CREATE TABLE IF NOT EXISTS quartet_status(run_id TEXT,quartet INTEGER,n_targets INTEGER,n_with_candidates INTEGER,n_blindspots INTEGER,status TEXT,chronology_status TEXT);
        CREATE TABLE IF NOT EXISTS blindspots(run_id TEXT,node_id TEXT,modality TEXT,reason TEXT,severity REAL,source TEXT);
        CREATE TABLE IF NOT EXISTS temporal_stops(run_id TEXT,quartet INTEGER,reason TEXT,source TEXT);
        CREATE TABLE IF NOT EXISTS audit_log(run_id TEXT,stage TEXT,status TEXT,detail TEXT,ts_utc TEXT);
        ''')
        c.commit()

    def audit(self,stage,status,detail=''):
        self.conn.execute('INSERT INTO audit_log VALUES(?,?,?,?,datetime("now"))',(self.run_id,stage,status,detail)); self.conn.commit()
        self.note(f'[{status}] {stage}: {detail}')

    def load_targets(self):
        p=(self.root/self.cfg['targets_csv']).resolve(); df=pd.read_csv(p)
        expected={'node_id','quartet','arm','l_pred_deg','b_pred_deg'}
        if not expected.issubset(df.columns): raise ValueError('targets CSV missing required columns')
        if len(df)!=1596: raise ValueError(f'expected 1596 target rows, got {len(df)}')
        if df['node_id'].duplicated().any(): raise ValueError('duplicate node_id')
        # normalize quartet integer
        df['quartet_i']=df['quartet'].astype(str).str.extract(r'(\d+)')[0].astype(int)
        ra,dec=gal_to_icrs(df.l_pred_deg.values,df.b_pred_deg.values); df['ra_deg']=ra; df['dec_deg']=dec
        df['state_index']=[4*(q-1)+ARM_ORDER.index(a)+1 for q,a in zip(df.quartet_i,df.arm)]
        # predicted jet tangent = bearing to next state on same arm; Q399 -> Rift closure
        lookup={(int(q),a):(float(r),float(d)) for q,a,r,d in zip(df.quartet_i,df.arm,df.ra_deg,df.dec_deg)}
        rra,rdec=gal_to_icrs([self.cfg['rift_l_deg']],[self.cfg['rift_b_deg']]); rra=float(rra[0]); rdec=float(rdec[0])
        pas=[]
        for q,a,r,d in zip(df.quartet_i,df.arm,df.ra_deg,df.dec_deg):
            nr,nd=lookup.get((int(q)+1,a),(rra,rdec)) if int(q)==399 else lookup[(int(q)+1,a)]
            pas.append(position_angle_deg(r,d,nr,nd))
        df['jet_pa_pred_deg']=pas
        lm=pd.read_csv((self.root/self.cfg['atomic_landmarks_csv']).resolve())
        lm_map={int(r.T_Z):(int(r.Z),str(r.label) if pd.notna(r.label) else '') for _,r in lm.iterrows()}
        df['atomic_Z_landmark']=[lm_map.get(int(s),(None,''))[0] for s in df.state_index]
        df['atomic_label']=[lm_map.get(int(s),(None,''))[1] for s in df.state_index]
        self.conn.execute('DELETE FROM targets')
        cols=['node_id','quartet_i','arm','pair','l_pred_deg','b_pred_deg','ra_deg','dec_deg','r_htm_kpc','phase_deg','block','six_pos','tilt_deg','handedness','spin_pred','catalog_class','search_radius_deg','preregistered_status','state_index','jet_pa_pred_deg','atomic_Z_landmark','atomic_label']
        vals=[]
        for _,r in df.iterrows():
            row=[]
            for col in cols:
                v=r.get(col,None)
                if pd.isna(v): v=None
                elif isinstance(v,np.generic): v=v.item()
                row.append(v)
            vals.append(tuple(row))
        self.conn.executemany('INSERT INTO targets VALUES('+','.join(['?']*22)+')',vals)
        self.conn.execute('INSERT OR REPLACE INTO runs VALUES(?,datetime("now"),?,?)',(self.run_id,json.dumps(self.cfg,sort_keys=True),sha256_file(p)))
        self.conn.commit(); self.audit('geometry_load','PASS',f'{len(df)} frozen target states loaded; no retuning')
        return df

    def validate_geometry(self,df):
        errors=[]
        g=df.groupby('quartet_i')['arm'].apply(list)
        for q,arms in g.items():
            if arms!=ARM_ORDER: errors.append(f'Q{q:03d} arm order={arms}')
        if df['quartet_i'].nunique()!=399: errors.append('quartet count != 399')
        if any(df['search_radius_deg'].astype(float)<=0): errors.append('nonpositive search radius')
        # constants audit only, derived from table
        tilts=sorted(round(x,4) for x in set(df.tilt_deg.astype(float)))
        if tilts!=[-19.4712,19.4712]: errors.append(f'unexpected tilt set {tilts}')
        if errors: self.audit('geometry_integrity','FAIL','; '.join(errors)); raise ValueError(errors[0])
        self.audit('geometry_integrity','PASS','399 complete quartets; B-,A+,B+,A- ordering; +/-19.4712 tilt')

    def ingest_candidates(self):
        df=self.read_csv_if('candidates.csv')
        if df is None: self.audit('candidate_ingest','SKIP','incoming/candidates.csv absent'); return None
        req={'candidate_id','ra_deg','dec_deg'}
        if not req.issubset(df.columns): raise ValueError('candidates.csv missing '+str(req-set(df.columns)))
        for c in ['z','object_class','source_catalog','designation','notes']:
            if c not in df: df[c]=None
        self.conn.execute('DELETE FROM candidates')
        self.conn.executemany('INSERT INTO candidates VALUES(?,?,?,?,?,?,?,?)',[(str(r.candidate_id),float(r.ra_deg),float(r.dec_deg),None if pd.isna(r.z) else float(r.z),None if pd.isna(r.object_class) else str(r.object_class),None if pd.isna(r.source_catalog) else str(r.source_catalog),None if pd.isna(r.designation) else str(r.designation),None if pd.isna(r.notes) else str(r.notes)) for _,r in df.iterrows()])
        self.conn.commit(); self.audit('candidate_ingest','PASS',f'{len(df)} candidates')
        return df

    def crossmatch_candidates(self,t,cand):
        if cand is None or cand.empty: return
        self.conn.execute('DELETE FROM target_candidates WHERE run_id=?',(self.run_id,))
        cra=cand.ra_deg.to_numpy(float); cdec=cand.dec_deg.to_numpy(float)
        out=[]
        for _,r in t.iterrows():
            sep=angular_sep_deg(np.full(len(cand),r.ra_deg),np.full(len(cand),r.dec_deg),cra,cdec)
            idx=np.where(sep<=float(r.search_radius_deg))[0]
            for j in idx:
                out.append((self.run_id,r.node_id,str(cand.iloc[j].candidate_id),float(sep[j]),1))
        self.conn.executemany('INSERT INTO target_candidates VALUES(?,?,?,?,?)',out); self.conn.commit()
        self.audit('candidate_crossmatch','PASS',f'{len(out)} target-candidate links inside frozen windows')

    def ingest_blindspots(self):
        df=self.read_csv_if('blindspots.csv')
        self.conn.execute('DELETE FROM blindspots WHERE run_id=?',(self.run_id,))
        if df is None: self.audit('blindspots','SKIP','none supplied'); return None
        for c in ['modality','reason','severity','source']:
            if c not in df: df[c]=None
        vals=[]
        for _,r in df.iterrows(): vals.append((self.run_id,str(r.node_id),str(r.modality or ''),str(r.reason or ''),None if pd.isna(r.severity) else float(r.severity),str(r.source or '')))
        self.conn.executemany('INSERT INTO blindspots VALUES(?,?,?,?,?,?)',vals); self.conn.commit(); self.audit('blindspots','PASS',f'{len(vals)} flags')
        return df

    def void_stencil(self,t):
        v=self.read_csv_if('voids.csv')
        self.conn.execute('DELETE FROM void_scores WHERE run_id=?',(self.run_id,))
        if v is None or v.empty: self.audit('void_stencil','SKIP','incoming/voids.csv absent'); return None
        req={'void_id','ra_deg','dec_deg'}
        if not req.issubset(v.columns): raise ValueError('voids.csv missing required columns')
        for c in ['angular_radius_deg','z','r_eff_mpc','weight','source']:
            if c not in v: v[c]=np.nan
        radii=[]; proxy=[]
        for _,r in v.iterrows():
            if pd.notna(r.angular_radius_deg): radii.append(float(r.angular_radius_deg)); proxy.append(0)
            elif pd.notna(r.z) and pd.notna(r.r_eff_mpc):
                da=flat_lcdm_DA_mpc(float(r.z)); th=np.rad2deg(float(r.r_eff_mpc)/da) if da>0 else np.nan
                radii.append(th); proxy.append(1)
            else: radii.append(np.nan); proxy.append(1)
        v['ang_r']=radii; v['proxy']=proxy
        v=v[np.isfinite(v.ang_r)].copy()
        if v.empty: self.audit('void_stencil','SKIP','no usable angular radii'); return None
        sigma=float(self.cfg.get('void_stencil_sigma_deg',1.0)); out=[]; best=[]
        vra=v.ra_deg.to_numpy(float); vdec=v.dec_deg.to_numpy(float); vr=v.ang_r.to_numpy(float)
        for _,r in t.iterrows():
            sep=angular_sep_deg(np.full(len(v),r.ra_deg),np.full(len(v),r.dec_deg),vra,vdec)
            res=np.abs(sep-vr); score=np.exp(-0.5*(res/sigma)**2)
            j=int(np.argmax(score))
            rr=v.iloc[j]
            out.append((self.run_id,r.node_id,str(rr.void_id),float(sep[j]),float(vr[j]),float(res[j]),float(score[j]),int(rr.proxy)))
            best.append(float(score[j]))
        self.conn.executemany('INSERT INTO void_scores VALUES(?,?,?,?,?,?,?,?)',out); self.conn.commit()
        self.audit('void_stencil','PASS',f'{len(out)} targets scored against void-shell stencil; mean best score={np.mean(best):.4f}')
        return v

    def jet_checks(self,t):
        j=self.read_csv_if('jets.csv')
        self.conn.execute('DELETE FROM jet_checks WHERE run_id=?',(self.run_id,))
        if j is None or j.empty: self.audit('jet_geometry','SKIP','incoming/jets.csv absent'); return None
        pred=t.set_index('node_id')['jet_pa_pred_deg'].to_dict()
        # candidate -> best linked node if node_id absent
        links=pd.read_sql_query('SELECT node_id,candidate_id,separation_deg FROM target_candidates WHERE run_id=? ORDER BY separation_deg',self.conn,params=[self.run_id])
        bestlink={} 
        for _,r in links.iterrows(): bestlink.setdefault(str(r.candidate_id),str(r.node_id))
        vals=[]
        for _,r in j.iterrows():
            node=str(r.node_id) if 'node_id' in j.columns and pd.notna(r.node_id) and str(r.node_id) else bestlink.get(str(r.candidate_id))
            if not node or node not in pred: continue
            obs=float(r.jet_pa_deg); pp=float(pred[node]); unc=None if 'pa_unc_deg' not in j.columns or pd.isna(r.pa_unc_deg) else float(r.pa_unc_deg)
            vals.append((self.run_id,node,str(r.candidate_id) if pd.notna(r.candidate_id) else '',obs,pp,axial_diff_deg(obs,pp),directed_diff_deg(obs,pp),unc,str(r.source) if 'source' in j.columns and pd.notna(r.source) else ''))
        self.conn.executemany('INSERT INTO jet_checks VALUES(?,?,?,?,?,?,?,?,?)',vals); self.conn.commit(); self.audit('jet_geometry','PASS',f'{len(vals)} observed jet PAs compared with frozen next-node tangent; axial and directed residuals both stored')
        return j

    def spectral_features(self):
        s=self.read_csv_if('spectra.csv')
        self.conn.execute('DELETE FROM spectral_features WHERE run_id=?',(self.run_id,))
        if s is None or s.empty: self.audit('spectral_features','SKIP','incoming/spectra.csv absent'); return None
        for c in ['candidate_id','node_id','component','freq_hz','flux']:
            if c not in s: s[c]='' if c in ['candidate_id','node_id','component'] else np.nan
        links=pd.read_sql_query('SELECT node_id,candidate_id,separation_deg FROM target_candidates WHERE run_id=? ORDER BY separation_deg',self.conn,params=[self.run_id])
        bestlink={}
        for _,r in links.iterrows(): bestlink.setdefault(str(r.candidate_id),str(r.node_id))
        minp=int(self.cfg.get('spectral_min_points',3)); vals=[]
        s=s[(pd.to_numeric(s.freq_hz,errors='coerce')>0)&(pd.to_numeric(s.flux,errors='coerce')>0)].copy()
        for (cid,comp),g in s.groupby(['candidate_id','component'],dropna=False):
            if len(g)<minp: continue
            x=np.log10(g.freq_hz.astype(float).values); y=np.log10(g.flux.astype(float).values)
            p1=np.polyfit(x,y,1); alpha=float(p1[0]); curv=np.nan
            if len(g)>=4: curv=float(np.polyfit(x,y,2)[0])
            explicit=[str(x) for x in g.node_id.dropna().unique() if str(x) and str(x).lower()!='nan']
            node=explicit[0] if explicit else bestlink.get(str(cid),'')
            sources=len(g['source'].dropna().astype(str).unique()) if 'source' in g else 0
            vals.append((self.run_id,node,str(cid),str(comp),len(g),alpha,None if not np.isfinite(curv) else curv,float(x.min()),float(x.max()),sources))
        self.conn.executemany('INSERT INTO spectral_features VALUES(?,?,?,?,?,?,?,?,?,?)',vals); self.conn.commit(); self.audit('spectral_features','PASS',f'{len(vals)} spectra fitted for alpha/curvature; no atomic claim imposed')
        return s

    def atomic_spectral_audit(self):
        self.conn.execute('DELETE FROM atomic_spectral_audit WHERE run_id=?',(self.run_id,))
        f=pd.read_sql_query('SELECT sf.*,t.state_index FROM spectral_features sf JOIN targets t ON t.node_id=sf.node_id WHERE sf.run_id=? AND sf.node_id<>""',self.conn,params=[self.run_id])
        lm=pd.read_csv((self.root/self.cfg['atomic_landmarks_csv']).resolve())
        half=int(self.cfg.get('atomic_probe_half_window_states',8)); vals=[]
        for _,r in lm.iterrows():
            if not str(r.get('label','')).strip() or f.empty: continue
            T=int(r.T_Z); before=f[(f.state_index>=T-half)&(f.state_index<T)]; after=f[(f.state_index>T)&(f.state_index<=T+half)]
            if len(before)>=2 and len(after)>=2:
                da=float(after.alpha.median()-before.alpha.median())
                bc=before.curvature.dropna(); ac=after.curvature.dropna(); dc=float(ac.median()-bc.median()) if len(bc)>=2 and len(ac)>=2 else np.nan
                st='EXPLORATORY_COMPUTED'
            else: da=np.nan; dc=np.nan; st='INSUFFICIENT_SPECTRA'
            vals.append((self.run_id,int(r.Z),T,str(r.node_id),str(r.label),len(before),len(after),None if not np.isfinite(da) else da,None if not np.isfinite(dc) else dc,st))
        self.conn.executemany('INSERT INTO atomic_spectral_audit VALUES(?,?,?,?,?,?,?,?,?,?)',vals); self.conn.commit(); self.audit('atomic_spectral_audit','PASS',f'{len(vals)} labeled atomic landmarks audited; results never alter frozen sky geometry')

    def temporal_and_quartets(self,t):
        self.conn.execute('DELETE FROM temporal_stops WHERE run_id=?',(self.run_id,)); self.conn.execute('DELETE FROM quartet_status WHERE run_id=?',(self.run_id,))
        st=self.read_csv_if('temporal_stops.csv'); stop_q=None
        if st is not None and not st.empty:
            for _,r in st.iterrows():
                q=int(r.quartet_index); self.conn.execute('INSERT INTO temporal_stops VALUES(?,?,?,?)',(self.run_id,q,str(r.reason) if 'reason' in st else '',str(r.source) if 'source' in st else ''))
                if q<400: stop_q=q if stop_q is None else min(stop_q,q)
        links=pd.read_sql_query('SELECT DISTINCT node_id FROM target_candidates WHERE run_id=?',self.conn,params=[self.run_id])
        has=set(links.node_id.astype(str)) if not links.empty else set()
        bs=pd.read_sql_query('SELECT DISTINCT node_id FROM blindspots WHERE run_id=?',self.conn,params=[self.run_id]); blind=set(bs.node_id.astype(str)) if not bs.empty else set()
        vals=[]
        candidate_data_present=(self.read_csv_if('candidates.csv') is not None)
        for q,g in t.groupby('quartet_i'):
            nodes=list(g.node_id.astype(str)); n=sum(n in has for n in nodes); nb=sum(n in blind for n in nodes)
            if not candidate_data_present: status='UNTESTED'
            elif n==4: status='CANDIDATE_COMPLETE'
            elif n>0: status='CANDIDATE_PARTIAL'
            elif nb>0: status='BLINDSPOT_ONLY'
            else: status='NO_CANDIDATE_IN_SUPPLIED_INPUT'
            chron='POST_TEMPORAL_STOP_UNCONFIRMED' if stop_q is not None and q>stop_q else ('TEMPORAL_STOP' if stop_q==q else 'OPEN')
            vals.append((self.run_id,int(q),4,n,nb,status,chron))
        self.conn.executemany('INSERT INTO quartet_status VALUES(?,?,?,?,?,?,?)',vals); self.conn.commit(); self.audit('quartet_cascade','PASS',f'399 quartet states written; temporal stop={stop_q}')

    def export(self):
        tables=['targets','target_candidates','void_scores','jet_checks','spectral_features','atomic_spectral_audit','quartet_status','blindspots','temporal_stops','audit_log']
        for tab in tables:
            if tab=='targets': df=pd.read_sql_query('SELECT * FROM targets ORDER BY state_index',self.conn)
            else: df=pd.read_sql_query(f'SELECT * FROM {tab} WHERE run_id=?',self.conn,params=[self.run_id])
            df.to_csv(self.out/f'{tab}.csv',index=False)
        summary={
            'run_id':self.run_id,
            'targets':int(pd.read_sql_query('SELECT count(*) n FROM targets',self.conn).n.iloc[0]),
            'candidate_links':int(pd.read_sql_query('SELECT count(*) n FROM target_candidates WHERE run_id=?',self.conn,params=[self.run_id]).n.iloc[0]),
            'void_scores':int(pd.read_sql_query('SELECT count(*) n FROM void_scores WHERE run_id=?',self.conn,params=[self.run_id]).n.iloc[0]),
            'jet_checks':int(pd.read_sql_query('SELECT count(*) n FROM jet_checks WHERE run_id=?',self.conn,params=[self.run_id]).n.iloc[0]),
            'spectral_features':int(pd.read_sql_query('SELECT count(*) n FROM spectral_features WHERE run_id=?',self.conn,params=[self.run_id]).n.iloc[0]),
            'principle':'geometry-first; no cross-fitting; atom/void/spectrum are independent audit channels',
        }
        (self.out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        (self.out/'run.log').write_text('\n'.join(self.log)+'\n',encoding='utf-8')
        self.audit('export','PASS',str(self.out))

    def run(self):
        self.init_schema(); t=self.load_targets(); self.validate_geometry(t)
        self.ingest_blindspots(); cand=self.ingest_candidates(); self.crossmatch_candidates(t,cand)
        self.void_stencil(t); self.jet_checks(t); self.spectral_features(); self.atomic_spectral_audit(); self.temporal_and_quartets(t); self.export()


def main():
    ap=argparse.ArgumentParser(description='HTM SMBH cascade')
    sub=ap.add_subparsers(dest='cmd',required=True)
    r=sub.add_parser('run'); r.add_argument('--config',default='config.json')
    args=ap.parse_args()
    c=Cascade(Path(args.config));
    try: c.run()
    finally: c.close()

if __name__=='__main__': main()
